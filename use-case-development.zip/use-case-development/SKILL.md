---
name: use-case-development
description: Use this skill whenever the user wants to map, elicit, define, or document use cases for a system — new or existing, any domain, any stack. Triggers on "mapear casos de uso", "levantar requisitos", "definir atores do sistema", "documentar cenários de uso", "criar UC-001", "quais fluxos esse sistema precisa ter", ou quando o usuário está começando a projetar um novo sistema/módulo/feature e precisa estruturar o que ele faz antes de codar. Não é um template estático — é um processo de elicitação: a skill conduz a conversa para descobrir atores, objetivos, fluxos alternativos e exceções que o usuário ainda não articulou, em vez de assumir que ele já chegou com tudo definido.
---

# Use Case Development

Casos de uso servem para uma coisa: forçar clareza sobre **o que o sistema faz para quem, e o que pode dar errado no meio do caminho** — antes que isso seja descoberto em produção. O valor não está no template preenchido, está no processo de elicitação que expõe lacunas.

Esta skill funciona para qualquer sistema, presente ou futuro — SaaS, automação, API, app interno, integração entre sistemas. Não assume um domínio específico. O trabalho é o mesmo sempre: descobrir atores reais, objetivos reais, e todos os jeitos de o cenário principal falhar.

**Regra central**: nunca preencha um caso de uso baseado no que parece óbvio. Pergunte. Um caso de uso escrito sem elicitação real é ficção bem formatada — não pega os fluxos alternativos que só o dono do domínio sabe que existem (aquele cliente que paga por boleto e cancela o pedido depois de emitido, aquele integrador externo que manda payload malformado uma vez por mês).

---

## Quando usar

- Usuário está desenhando um sistema/feature novo e precisa estruturar o comportamento antes de implementar
- Usuário pede para "mapear casos de uso", "levantar requisitos", "documentar fluxos"
- Usuário tem uma ideia solta ("quero um sistema que gerencie X") e precisa transformar isso em algo implementável
- Usuário já tem um sistema em produção e quer documentar o comportamento real para onboarding, handoff, ou auditoria (nesse caso, elicitação vira "leitura de código + confirmação com o usuário", não pura entrevista)

Não usar para: documentação de API técnica pura (endpoints, schemas — isso é referência, não caso de uso), ou para especificação de UI/wireframe (caso de uso é technology-independent por definição).

---

## Workflow

```
1. Escopo       → que sistema, que fronteira, que nível de granularidade
2. Atores       → quem/o que interage com o sistema (primário, secundário, offstage)
3. Objetivos    → o que cada ator quer alcançar (não "o que ele clica")
4. Cenário base → o caminho feliz, passo a passo, sem desvios
5. Variações    → para cada passo: o que pode variar ou falhar
6. Regras       → pré-condições, pós-condições, regras de negócio implícitas
7. Documentar   → formato estruturado + checklist de qualidade
8. Priorizar    → o que é crítico para o MVP vs. o que é caso de borda aceitável depois
```

### 1. Escopo — antes de tudo

Pergunte (não assuma):
- **Fronteira do sistema**: onde o sistema em questão termina e outro começa? (ex: "processar pagamento" é caso de uso do seu sistema, ou é caixa-preta do gateway de pagamento que você só invoca?)
- **Nível de granularidade** (ver `references/granularity-levels.md`): você quer casos de uso de **negócio** (o que a empresa faz, sem menção a sistema — "processar devolução de cliente") ou casos de uso de **sistema** (o que este software específico faz — "cliente submete formulário de devolução via portal")? A maioria dos pedidos técnicos quer o segundo, mas confirme.
- **Estado do sistema**: é greenfield (nada existe ainda, elicitação é 100% conversa) ou já existe algo rodando (elicitação combina leitura de código/comportamento observado com confirmação)?

Se o usuário não sabe responder essas perguntas com precisão, é sinal de que o escopo ainda está nebuloso — não force um caso de uso formal ainda, ajude a fechar o escopo primeiro com 2-3 perguntas diretas.

### 2. Atores — identificar todos, não só o óbvio

Todo sistema tem mais atores do que o usuário lista de cara. Pergunte especificamente por:
- **Ator primário**: quem inicia a interação para alcançar um objetivo (geralmente óbvio: "cliente", "administrador")
- **Atores secundários/de suporte**: sistemas ou pessoas que o sistema principal precisa para completar o caso de uso, mas que não iniciam a ação (gateway de pagamento, serviço de e-mail, API de terceiro, outro departamento)
- **Atores "offstage"**: interessados que não interagem diretamente mas têm interesse no resultado (compliance, auditoria, o dono do negócio que só quer o relatório no final)
- **Múltiplos papéis do mesmo ator**: "administrador" às vezes esconde 2-3 papéis distintos com objetivos diferentes (admin de conteúdo ≠ admin financeiro) — vale a pena separar se os objetivos divergem

Não aceite "o sistema" como ator — sistemas são atores secundários de outros casos de uso, nunca o ator primário do caso de uso que você está descrevendo agora.

### 3. Objetivos — o "porquê" antes do "como"

Para cada ator primário, pergunte o objetivo em nível de negócio, não de interface:
- Errado: "usuário clica em salvar"
- Certo: "usuário garante que o pedido não será perdido se a conexão cair"

Um caso de uso nasce de um objetivo de nível de usuário (Cockburn chama de "sea level" — o nível onde a maioria dos casos de uso deveria viver). Objetivos maiores que isso ("gerenciar todo o negócio") são épicos, não casos de uso — quebre em objetivos menores e atômicos. Objetivos menores que isso ("clicar no botão X") são passos dentro de um cenário, não casos de uso próprios.

### 4. Cenário principal (main success scenario)

Uma vez com ator + objetivo claros, construa o caminho feliz:
- Numere os passos
- Cada passo é uma interação atômica entre ator e sistema (ator faz algo → sistema responde algo)
- Não insira decisões/condicionais aqui — isso vai para as variações (passo 5)
- Termine no momento em que o objetivo do ator foi alcançado (pós-condição satisfeita)

### 5. Variações — o passo mais importante e mais pulado

Para **cada** passo do cenário principal, pergunte explicitamente: "o que pode dar diferente aqui?" Categorize em:
- **Fluxos alternativos**: variações válidas do caminho (ex: cliente escolhe pagamento diferente) — o objetivo ainda é alcançado, só por um caminho diferente
- **Fluxos de exceção**: algo impede o objetivo de ser alcançado como planejado (erro de validação, timeout, indisponibilidade de um ator secundário) — precisa de uma resolução explícita (retry, notificação, rollback, fallback)

Não deixe o usuário pular essa etapa dizendo "depois a gente vê os erros" — é exatamente aqui que sistemas reais quebram, e é mais barato descobrir agora do que em produção. Se o usuário genuinamente não sabe uma variação, pergunte diretamente: "o que acontece se [ator secundário] estiver fora do ar nesse momento?", "o que acontece se o mesmo ator tentar isso duas vezes?", "existe um caso onde dois atores tentam a mesma ação ao mesmo tempo?".

### 6. Regras — pré-condições, pós-condições, invariantes

- **Pré-condição**: o que precisa ser verdade antes do caso de uso começar (se não for verdade, o sistema nem deveria oferecer a ação)
- **Pós-condição de sucesso**: o que é garantidamente verdade depois do cenário principal
- **Pós-condição mínima de falha**: o que é garantido mesmo quando um fluxo de exceção acontece (ex: "o carrinho nunca é perdido, mesmo se o pagamento falhar")
- **Regras de negócio implícitas**: restrições que não aparecem nos passos mas afetam o caso de uso (limites, janelas de tempo, permissões) — pergunte por elas explicitamente, geralmente vivem só na cabeça do usuário

### 7. Documentar

Use o template em `references/template.md`. Estrutura mínima obrigatória por caso de uso:

```
UC-ID | Nome | Ator(es) | Nível (sea/summary/kernel)
Pré-condição
Pós-condição (sucesso) / Pós-condição mínima (falha)
Cenário principal (numerado)
Fluxos alternativos (referenciados por número do passo, ex: 3a)
Fluxos de exceção (idem)
Regras de negócio relevantes
Frequência/prioridade (para estimativa)
```

Depois de escrever, rode o `references/quality-checklist.md` antes de considerar pronto.

### 8. Priorização

Nem todo caso de uso é MVP. Depois de mapear, ajude o usuário a classificar:
- **Crítico**: sem isso o sistema não cumpre seu propósito central
- **Importante**: sistema funciona sem, mas com atrito real para o usuário
- **Borda aceitável para depois**: cenário raro, custo de implementar agora não compensa

Isso vira insumo direto para estimativa de esforço e para sequenciamento de desenvolvimento — não deixe o mapeamento parar em "lista completa de casos de uso" sem essa camada de priorização, porque é isso que o usuário realmente precisa para decidir o que construir primeiro.

---

## Diagrama de relacionamento (quando útil)

Casos de uso podem se relacionar via `<<include>>` (um caso de uso sempre invoca outro, ex: "Finalizar Pedido" inclui "Processar Pagamento") ou `<<extend>>` (um caso de uso opcionalmente estende outro em certas condições, ex: "Aplicar Cupom" estende "Finalizar Pedido"). Use isso para evitar duplicar o mesmo fluxo em múltiplos casos de uso — mas não force o diagrama se o usuário só precisa de 2-3 casos de uso simples; overhead de UML não vale a pena em escopos pequenos.

---

## References

- `references/granularity-levels.md` — como diferenciar caso de uso de negócio vs. sistema, e nível summary/sea/kernel (Cockburn)
- `references/template.md` — template completo pronto para copiar, com exemplo preenchido
- `references/quality-checklist.md` — critérios objetivos para saber se um caso de uso está completo e bem formado antes de considerar pronto
- `references/elicitation-questions.md` — banco de perguntas prontas para cada etapa do workflow, para usar quando o usuário trava ou não sabe por onde começar

Carregue as referências relevantes por etapa — não é necessário puxar todas de uma vez para mapear um caso de uso simples.
