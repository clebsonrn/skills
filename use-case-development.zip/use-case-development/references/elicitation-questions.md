# Elicitation Questions — Use Case Development

Banco de perguntas prontas, organizado pela mesma ordem do workflow no SKILL.md. Use quando o usuário travar, disser "não sei" ou pedir para você "só definir" sem dar contexto — a resposta certa quase nunca é inventar, é perguntar isto.

## 1. Escopo

- "Esse sistema já existe ou estamos desenhando do zero?"
- "Onde esse sistema termina? O que ele chama/depende, mas não controla?"
- "Você quer casos de uso de negócio (o que a empresa faz) ou de sistema (o que este software específico faz)?"
- "Isso é um sistema novo inteiro, ou uma feature/módulo dentro de algo que já existe?"

## 2. Atores

- "Quem inicia essa ação — uma pessoa, outro sistema, um job agendado?"
- "Esse sistema depende de algum serviço externo pra completar essa ação (pagamento, e-mail, API de terceiro)? Isso é um ator secundário."
- "Existe alguém que não usa o sistema diretamente, mas que se importa com o resultado (financeiro, compliance, um gestor que só vê o relatório)?"
- "'Administrador' aqui é um papel único, ou existem administradores com objetivos bem diferentes entre si (ex: admin de conteúdo vs. admin financeiro)?"

## 3. Objetivos

- "Se esse caso de uso terminar com sucesso, o que exatamente o [ator] ganhou?"
- "Isso é algo que o [ator] consegue completar numa sessão só, ou é um processo maior que se estende por dias/etapas?"
- "Por que o [ator] quer isso — o que ele estava tentando resolver antes de chegar nessa ação?"

## 4. Cenário principal

- "Descreve o caminho onde tudo dá certo, sem pensar em erro por enquanto — o que acontece primeiro, depois, depois?"
- "Em algum desses passos o sistema decide algo automaticamente, ou é sempre o [ator] decidindo?"
- "Qual é o último passo — o momento exato em que você diria 'pronto, terminou'?"

## 5. Variações (a etapa que mais precisa de perguntas ativas)

Para cada passo do cenário principal, perguntar:
- "O que acontece se [ator secundário desse passo] estiver indisponível nesse momento?"
- "Existe uma forma válida, mas diferente, de completar esse passo específico?"
- "O que acontece se o [ator] tentar repetir esse passo (clique duplo, retry manual, requisição reenviada)?"
- "Alguma vez dois [atores] podem tentar isso ao mesmo tempo? O que deveria acontecer?"
- "Se esse passo falhar, o que já foi feito nos passos anteriores precisa ser desfeito, ou fica como está?"
- "Existe algum limite (tempo, quantidade, valor) que, se ultrapassado, muda o comportamento esperado aqui?"

Perguntas de fechamento depois de mapear as variações óbvias:
- "Pensando nos últimos 6 meses, teve algum caso estranho/exceção que aconteceu de verdade e não está coberto aqui ainda?"
- "Que reclamação de usuário, se existisse, indicaria que esse caso de uso está incompleto?"

## 6. Regras de negócio

- "Existe algum limite de quantidade, valor ou frequência aqui que não é óbvio só olhando os passos?"
- "Isso vale igual para todo mundo, ou tem exceção por tipo de cliente/plano/região?"
- "Essa regra está documentada em algum lugar, ou só vive na sua cabeça / na cabeça de alguém do time?"

## 7. Priorização

- "Se você tivesse que cortar isso do MVP, o sistema ainda cumpriria o propósito central dele?"
- "Com que frequência esse cenário específico (alternativo/exceção) realmente acontece na prática?"
- "O custo de não tratar esse caso agora é reversível depois, ou vira dívida técnica cara de desfazer?"

## Quando o usuário está no papel de "dono do domínio" mas não de escritor de UC

Se o usuário claramente sabe as respostas mas não pensa em termos de "atores e cenários" (comum — é normal), não peça para ele "escrever o caso de uso". Peça para ele contar a história em linguagem natural ("me conta como funciona hoje, do início ao fim, incluindo o que já deu errado alguma vez") e você estrutura depois. Elicitação boa parece conversa, não formulário.
