# Quality Checklist — Use Case Development

Rode este checklist antes de considerar um caso de uso pronto. Cada item é uma pergunta de sim/não — se a resposta for "não" ou "meio que", o caso de uso ainda não está pronto.

## Objetivo e escopo

- [ ] O nome do caso de uso é "Verbo + Objeto" na perspectiva do ator (não um substantivo genérico tipo "Gestão de Pedidos")?
- [ ] O objetivo é de nível sea-level — nem grande demais (é um épico disfarçado) nem pequeno demais (é um passo disfarçado de UC)? Ver `granularity-levels.md`.
- [ ] O caso de uso é tecnologicamente independente — não menciona botões, telas ou tecnologias específicas, só o que o ator quer alcançar? (Exceção: quando a interface em si é o requisito, ex: "via API REST" quando isso é uma restrição real de negócio, não decisão de UI arbitrária.)
- [ ] Dá para responder "o ator ganhou valor real se o cenário principal terminar aqui?" com sim?

## Atores

- [ ] O ator primário é quem *inicia* a ação, não quem só é afetado por ela?
- [ ] Atores secundários necessários para completar o cenário estão listados (não só o primário)?
- [ ] Se "sistema" aparece como se fosse um ator do próprio caso de uso, isso foi corrigido (sistema é o executor, não o ator)?

## Cenário principal

- [ ] Cada passo é uma interação atômica (ator age → sistema responde), sem condicionais embutidas no meio do passo?
- [ ] O cenário principal é só o caminho feliz — nenhum "se/então" morando ali (isso pertence às variações)?
- [ ] O último passo entrega a pós-condição de sucesso declarada?

## Variações — a parte mais fácil de pular

- [ ] Existe pelo menos um fluxo de exceção documentado para cada ponto do cenário onde um ator secundário é chamado (rede pode falhar, serviço pode estar fora do ar)?
- [ ] Existe fluxo para "e se o ator tentar isso de novo" (duplo clique, retry, requisição duplicada)?
- [ ] Existe fluxo para "e se dois atores tentarem simultaneamente" quando isso é fisicamente possível (concorrência)?
- [ ] Cada fluxo de exceção tem uma resolução explícita, não só "sistema mostra erro" sem dizer o que acontece com o estado (dado é perdido? preservado? revertido?)?
- [ ] Se o caso de uso tem mais de 5 passos e **zero** fluxos de exceção, isso foi questionado explicitamente com o usuário antes de aceitar como "completo"?

## Pré/pós-condições

- [ ] A pré-condição é algo que o sistema pode genuinamente verificar antes de começar (não uma suposição vaga)?
- [ ] Existe uma pós-condição mínima de falha — o que é garantido mesmo quando o caso de uso não termina em sucesso?
- [ ] As pós-condições não contradizem regras de negócio mencionadas em outro caso de uso do mesmo sistema (checar consistência cruzada quando há múltiplos UCs)?

## Regras de negócio

- [ ] Restrições que vivem só na cabeça do usuário (limites, janelas de tempo, exclusividade) foram perguntadas explicitamente e documentadas, não deixadas implícitas?

## Consistência do conjunto (quando há múltiplos casos de uso)

- [ ] Todos os UCs do conjunto estão no mesmo nível de granularidade (não misturando summary com sea level sem indicar)?
- [ ] Relacionamentos `<<include>>`/`<<extend>>` entre UCs foram identificados, evitando fluxo duplicado em múltiplos documentos?
- [ ] Cada UC tem prioridade atribuída (crítico/importante/aceitável depois) — o conjunto não é só uma lista plana sem hierarquia de importância?

---

Se todos os itens aplicáveis estiverem marcados, o caso de uso está pronto para virar insumo de estimativa, backlog, ou especificação técnica. Se não, volte para a etapa de elicitação correspondente no SKILL.md em vez de forçar o documento a "parecer completo".
