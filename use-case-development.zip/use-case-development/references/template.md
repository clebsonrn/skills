# Template — Use Case Development

Copie a estrutura abaixo por caso de uso. O exemplo preenchido serve de calibração de nível de detalhe — nem raso demais (vira só um título), nem granular demais (vira pseudocódigo).

## Template vazio

```markdown
**UC-ID:** UC-XXX
**Nome:** [Verbo + Objeto, na perspectiva do ator — "Cliente Finaliza Pedido", não "Finalização de Pedido"]
**Nível:** [Summary / Sea level / Subfunction]
**Ator primário:** [quem inicia]
**Atores secundários:** [sistemas/pessoas de suporte necessários]
**Interessados offstage:** [quem tem interesse no resultado sem participar diretamente]

**Pré-condições:**
- [O que precisa ser verdade antes de o caso de uso poder começar]

**Pós-condição (sucesso):**
- [O que é garantidamente verdade ao final do cenário principal]

**Pós-condição mínima (falha):**
- [O que é garantido mesmo se um fluxo de exceção interromper o caso de uso]

**Cenário principal:**
1. [Ator faz algo]
2. [Sistema responde]
3. ...
N. [Objetivo alcançado]

**Fluxos alternativos:**
- Na (variação válida do passo N):
  Na1. ...
  Na2. Retoma no passo [X]

**Fluxos de exceção:**
- Na (algo impede o objetivo):
  Na1. [O que o sistema faz]
  Na2. [Resolução — retry, notificação, rollback]

**Regras de negócio relevantes:**
- [Restrições que não aparecem nos passos mas afetam o comportamento]

**Frequência estimada:** [quantas vezes/dia, ou "sob demanda"]
**Prioridade:** [Crítico / Importante / Aceitável para depois]
```

## Exemplo preenchido (domínio genérico, e-commerce)

```markdown
**UC-ID:** UC-014
**Nome:** Cliente Finaliza Pedido
**Nível:** Sea level
**Ator primário:** Cliente
**Atores secundários:** Gateway de Pagamento, Serviço de E-mail, Sistema de Estoque
**Interessados offstage:** Financeiro (precisa que o pedido só seja criado com pagamento confirmado)

**Pré-condições:**
- Cliente está autenticado
- Carrinho contém ao menos 1 item válido

**Pós-condição (sucesso):**
- Pedido criado com status "confirmado"
- Estoque decrementado
- E-mail de confirmação enviado
- Carrinho esvaziado

**Pós-condição mínima (falha):**
- Carrinho nunca é perdido, independentemente do ponto de falha
- Nenhum pedido é criado sem confirmação de pagamento

**Cenário principal:**
1. Cliente revisa itens do carrinho
2. Cliente confirma endereço de entrega
3. Cliente seleciona método de pagamento
4. Sistema envia requisição ao Gateway de Pagamento
5. Gateway confirma pagamento aprovado
6. Sistema decrementa estoque dos itens
7. Sistema cria pedido com status "confirmado"
8. Sistema envia e-mail de confirmação ao cliente

**Fluxos alternativos:**
- 3a. Cliente aplica cupom de desconto antes de selecionar pagamento
  3a1. Sistema valida cupom e recalcula total
  3a2. Retoma no passo 3

**Fluxos de exceção:**
- 5a. Gateway recusa o pagamento
  5a1. Sistema exibe motivo da recusa ao cliente
  5a2. Cliente seleciona método de pagamento diferente
  5a3. Retoma no passo 4
- 5b. Gateway não responde dentro do timeout
  5b1. Sistema marca tentativa como pendente, não cria pedido
  5b2. Sistema notifica cliente para tentar novamente
  5b3. Carrinho é preservado
- 6a. Item ficou sem estoque entre o passo 1 e o passo 6 (condição de corrida)
  6a1. Sistema reverte a cobrança já processada no Gateway
  6a2. Sistema notifica cliente sobre indisponibilidade do item
  6a3. Sistema sugere item alternativo ou remoção do item do carrinho

**Regras de negócio relevantes:**
- Estoque só é decrementado após confirmação de pagamento, nunca antes (evita reservar estoque de pagamentos que podem falhar)
- Cupons de desconto não são cumulativos

**Frequência estimada:** Alta — dezenas a centenas por dia dependendo do volume da operação
**Prioridade:** Crítico
```

Note que o exemplo tem **três** fluxos de exceção diferentes para o mesmo cenário principal curto de 8 passos — isso é normal e esperado. Um caso de uso com cenário principal de 8 passos e zero fluxos de exceção documentados quase certamente não passou por elicitação real.
