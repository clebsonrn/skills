# Níveis de Granularidade — Use Case Development

Baseado na notação de Alistair Cockburn ("Writing Effective Use Cases"). Usar para decidir em que altura escrever cada caso de uso — o erro mais comum é misturar níveis no mesmo documento.

## Negócio vs. Sistema

- **Caso de uso de negócio**: descreve o que a empresa faz, independente de qual sistema (ou se existe sistema) executa. Ex: "Processar devolução de cliente" — pode envolver humano no telefone, sistema, ou os dois.
- **Caso de uso de sistema**: descreve o comportamento de um software específico. Ex: "Cliente submete formulário de devolução via portal de autoatendimento" — já assume a existência do sistema.

A maioria dos pedidos de desenvolvimento quer o nível de **sistema**. Casos de uso de negócio são úteis em fase de discovery/consultoria, antes de decidir que sistema construir.

## Os três níveis de altitude (sea level / summary / kernel)

Cockburn usa símbolos de nuvem/pipa/mar/peixe/concha para isso — na prática, o que importa é a altitude:

### Summary level (nuvem) ☁️
Objetivos muito amplos, geralmente compostos por vários casos de uso sea-level. Ex: "Gerenciar Relacionamento com Cliente". Útil para dar contexto de negócio, mas não é implementável diretamente — quebre em casos de uso menores antes de especificar fluxos.

### User goal / sea level (mar) 🌊 — **o nível padrão para a maioria dos casos de uso**
Um ator alcança um objetivo completo, de forma atômica, sem interrupção. Ex: "Cliente Finaliza Pedido", "Administrador Cadastra Novo Produto". Este é o nível onde a estrutura completa (pré/pós-condição, cenário principal, alternativas, exceções) faz sentido e vale o esforço de escrever.

**Regra prática**: se o objetivo pode ser abandonado a qualquer momento sem perda de valor para o ator, e retomado do zero depois, provavelmente é sea-level. Se leva minutos/segundos e termina com algo de valor entregue, é sea-level.

### Subfunction level (peixe/concha) 🐟
Passos que só fazem sentido dentro de um caso de uso maior, não têm valor sozinhos para o ator. Ex: "Validar CPF", "Calcular Frete". Normalmente não merecem um UC completo — viram um passo ou um fluxo `<<include>>` dentro de um caso de uso sea-level.

## Como decidir na prática

Pergunta de teste: **"Se eu parar aqui, o ator ganhou algo de valor?"**
- Sim, e é um objetivo completo → sea level, escreva o caso de uso completo
- Sim, mas é maior que uma sessão de interação → provavelmente summary, quebre em partes
- Não, é só um passo intermediário → subfunction, não merece UC próprio

## Erro comum a evitar

Misturar altitudes no mesmo conjunto de casos de uso deixa o documento inconsistente — um UC gigante de nível summary ao lado de um UC minúsculo de nível subfunction, ambos numerados como se fossem equivalentes. Ao mapear um sistema, primeiro liste os objetivos summary-level (contexto), depois quebre cada um nos sea-level correspondentes (esses são os que ganham documentação completa), e só desça a subfunction quando um fluxo se repete em múltiplos UCs e vale a pena extrair.
