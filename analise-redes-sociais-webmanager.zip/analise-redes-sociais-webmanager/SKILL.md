---
name: analise-redes-sociais-webmanager
description: Analisa o desempenho de redes sociais (Instagram, YouTube) de qualquer projeto do WebManagerF5. Mostra o que performa, quais formatos de post nunca foram testados e o que fazer para crescer em seguidores e engajamento, em linguagem simples para leigos. Usar quando pedirem análise de redes sociais, de Instagram, de perfil, de conteúdo, "o que postar", "como crescer" ou "o que performa melhor".
---

# Análise de redes sociais via WebManagerF5

Procedimento padrão para qualquer projeto/conta. Nunca assumir um projeto fixo: sempre identificar o projeto no início.

## 1. Identificar o projeto e a conta

1. Se o usuário não informou o projeto, chamar `list_projects` e escolher pelo nome citado. Se houver ambiguidade, perguntar (uma pergunta curta).
2. Conferir em `integracoes` se Instagram/YouTube estão configurados e em `integracoes_expiradas` se o token foi recusado. Se expirado, avisar que os dados estão parados e que é preciso reconectar; não analisar como se estivessem atuais.
3. Se o projeto tiver várias contas de Instagram, usar o parâmetro `instagram_account` (@username). Sem ele, a conta principal é usada; dizer qual foi usada.
4. Período: usar o pedido; se não houver, 30 dias para visão geral e 90 para conteúdo.

## 2. Coletar dados (em paralelo)

- `get_instagram_overview` (dias 7/30/90): seguidores, novos seguidores, alcance, visualizações, visitas ao perfil, cliques no link da bio.
- `get_instagram_content` (dias 30/60/90/180, top até 30, ordenar por alcance e depois por taxa_engajamento): desempenho por tipo (REEL, VIDEO, CAROUSEL_ALBUM, IMAGE) e melhores posts, com timestamp para cruzar horário x alcance.
- `get_instagram_stories` (7/14/30/90): impressões, alcance, respostas.
- `get_instagram_audience`: gênero, faixa etária, cidades, horários de pico.
- Se o projeto tiver YouTube: `get_youtube_overview` e `get_youtube_videos` (tipo video/short/live).

## 3. Cuidados com os dados (sempre aplicar)

- `null` significa não coletado, não zero. Não calcular nem concluir em cima de null.
- `alcance_soma_diaria` não é alcance único do período; não comparar com seguidores como se fosse.
- Taxa de engajamento = interações / alcance (não / seguidores). Não comparar com benchmarks que usam seguidores no denominador sem avisar.
- Posts com alcance null ficam fora das médias; informar quantos.
- Insights da Meta chegam com ~2 dias de atraso e o YouTube com ~3. Checar o bloco `cobertura` e informar a última data coletada.
- Poucos posts por formato (menos de ~5) ou base pequena de seguidores: tratar como indício, não como conclusão.

## 4. Análise

1. **Onde a conta está**: seguidores, novos seguidores, alcance e visitas ao perfil no período (e variação, se houver período anterior).
2. **O que performa**: ranking dos formatos por alcance e por taxa de engajamento; 3 melhores e 3 piores posts, com o que têm em comum (formato, horário, tema aparente no que os dados mostram).
3. **Formatos não testados ou pouco usados**: comparar os formatos presentes (Reel, Carrossel, Imagem, Vídeo de feed, Stories) com a lista completa. Marcar como "nunca usado" quem tem 0 posts no período e "pouco testado" quem tem poucos posts. Não afirmar que o formato funcionaria; apresentar como teste a fazer.
4. **Horários**: cruzar timestamps dos posts com alcance e com os horários de pico da audiência.
5. **Conversão do perfil**: relação alcance -> visitas ao perfil -> cliques no link da bio -> novos seguidores.

## 5. Recomendações

- No máximo 3 a 5 ações, priorizadas, cada uma com: o que fazer, por que (dado que sustenta) e como medir.
- Incluir sempre pelo menos 1 teste de formato não usado, descrito como experimento (ex.: 4 posts em 2 semanas, comparar com a média atual).
- Separar claramente: **dado** (veio do WebManager), **inferência** (leitura sobre os dados) e **hipótese a testar**. Não afirmar causa sem evidência.
- Se os dados forem insuficientes para uma conclusão, dizer isso e o que falta.

## 6. Formato da resposta

- Português, direto, sem jargão. Termos técnicos (alcance, taxa de engajamento) explicados em uma linha na primeira vez.
- Estrutura: Resumo em 3 linhas -> O que está funcionando -> O que não foi testado -> Ações priorizadas -> Limites dos dados.
- Para leigo: usar comparações simples ("seus Reels alcançam X vezes mais gente que imagens") apenas quando os números sustentarem.
- Só gerar painel/arquivo se o usuário pedir; por padrão responder no chat.
